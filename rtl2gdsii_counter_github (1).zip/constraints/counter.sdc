# Placeholder/reference SDC.
# Genus generates the actual counter.sdc during synthesis.
# Keep this file as documentation only unless your flow requires
# an input SDC.

create_clock -name clk -period 5.0 [get_ports clk]
