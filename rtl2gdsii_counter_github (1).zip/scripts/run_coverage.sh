#!/bin/csh
# Cadence Incisive/Xcelium coverage flow
csh
source /cad/install/cshrc
cd ../tb
irun ../rtl/counter.v counter_test.v -access +rwc -coverage all -gui
