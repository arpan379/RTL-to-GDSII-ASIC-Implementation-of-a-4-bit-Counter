#!/bin/csh
# Cadence RTL simulation helper
csh
source /cad/install/cshrc
nclaunch -new
