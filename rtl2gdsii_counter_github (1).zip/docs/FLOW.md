# RTL-to-GDSII Flow Explained

## 1. RTL

`rtl/counter.v` describes the 4-bit counter behavior in Verilog.

## 2. Verification

`tb/counter_test.v` generates a clock and reset sequence and observes `out`.

The manual uses Cadence Incisive/SimVision for compilation, elaboration, and simulation.

## 3. Coverage

The manual describes block, branch, statement, expression, toggle, and FSM coverage.

The example coverage command is:

```text
irun counter.v counter_test.v -access +rwc -coverage all -gui
```

IMC is then used to inspect coverage data.

## 4. Synthesis

Genus converts the RTL into a gate-level implementation using the target standard-cell library.

The script:
- reads RTL
- elaborates the top module
- defines the clock
- applies input/output delays
- checks the design
- synthesizes and maps the design
- writes the netlist and SDC
- generates timing, area, and power reports

## 5. IO / Pad planning

The design has:
- `clk`
- `rst`
- `out[3:0]`
- `VDD`
- `VSS`
- `VDDO`
- `VSSO`

The padframe file assigns IO cells around the chip boundary.

## 6. Physical design

Innovus performs:
1. design import
2. floorplanning
3. IO filler insertion
4. power-ring/grid construction
5. placement
6. CTS
7. routing
8. post-route optimization
9. filler insertion
10. GDSII stream-out

## 7. GDSII and Virtuoso

The manual then imports the generated GDSII into Cadence Virtuoso for layout inspection.
