#!/bin/csh
# Cadence Innovus helper
csh
source /cad/install/cshrc
innovus
