#!/bin/csh
# Cadence Genus synthesis helper
csh
source /cad/install/cshrc
cd ../synthesis
genus -legacy_ui -f synth_script.tcl
