# GitHub / Lab Checklist

## RTL
- [ ] `rtl/counter.v`
- [ ] `tb/counter_test.v`
- [ ] RTL simulation passes
- [ ] Waveform checked

## Coverage
- [ ] Coverage run completed
- [ ] Block coverage checked
- [ ] Toggle coverage checked
- [ ] Any uncovered behavior explained

## Synthesis
- [ ] PDK paths updated
- [ ] Genus elaboration passes
- [ ] `counter_netlist.v` generated
- [ ] `counter.sdc` generated
- [ ] Timing report generated
- [ ] Area report generated
- [ ] Power report generated
- [ ] Positive timing slack checked

## Physical design
- [ ] IO assignment completed
- [ ] Netlist pad modification completed
- [ ] MMMC/SDC path updated
- [ ] Design imported into Innovus
- [ ] Floorplan completed
- [ ] IO fillers inserted
- [ ] Power rings/grid completed
- [ ] Placement completed
- [ ] CTS completed
- [ ] Routing completed
- [ ] Post-route optimization completed
- [ ] Fillers inserted
- [ ] Final GDSII generated

## Final verification / inspection
- [ ] GDSII imported into Virtuoso
- [ ] Final layout inspected
- [ ] Final screenshots added to `docs/`
- [ ] Reports copied to `reports/`
