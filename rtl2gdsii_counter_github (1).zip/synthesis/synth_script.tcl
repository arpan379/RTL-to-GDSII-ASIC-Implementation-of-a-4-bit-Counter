# Cadence Genus synthesis script
# IMPORTANT: Update PDK_ROOT and DESIGN_ROOT for your machine.
# The paths in the lab manual are installation/user-specific.

set PDK_ROOT    "/path/to/pdk/scl_pdk"
set DESIGN_ROOT "/path/to/rtl2gdsii_counter"

set_attribute init_lib_search_path "$PDK_ROOT/stdlib/fs120/liberty/lib_flow_ss"
set_attribute library tsl18fs120_scl_ss.lib
set_attribute init_hdl_search_path "$DESIGN_ROOT/rtl"
set_attribute information_level 6

set myFiles [list counter.v]
set basename counter
set myClk clk
set myPeriod_ps 5000
set myInDelay_ns 1
set myOutDelay_ns 1
set runname synth_report

read_hdl ${myFiles}
elaborate ${basename}

set clock [define_clock -period ${myPeriod_ps} -name ${myClk} [clock_ports]]
external_delay -input $myInDelay_ns -clock ${myClk} [find / -port ports_in/*]
external_delay -output $myOutDelay_ns -clock ${myClk} [find / -port ports_out/*]

dc::set_clock_transition .1 $myClk

check_design -unresolved
report_timing -lint

set_attribute syn_generic_effort high
set_attribute syn_map_effort high
set_attribute syn_opt_effort high

synthesize -to_mapped
syn_generic
syn_map
syn_opt

write_hdl > counter_netlist.v
write_sdc > counter.sdc

report_timing > counter_timing.rep
report_gates  > counter_area.rep
report_power  > counter_power.rep
